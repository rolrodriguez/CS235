#include "student.h"

Student ::Student(string student)
{
  studentText = student;

  std::stringstream ss(student);
  string word;

  ss >> word;

  if (word == "!!")
  {
    emergency = true;
    ss >> word;
    className = word;
  }
  else
  {
    className = word;
    emergency = false;
  }

  ss >> word;
  name = word;

  ss >> word;
  time = atoi(word.c_str());
}